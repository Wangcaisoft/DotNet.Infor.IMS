### ION API Authorized app creation

Follow these steps:
	1. Open Infor ION API gateway.
	2. Go to Authorized Apps
	3. Click on the plus button(Add New App).
	4. Give name in 'Name' text field and select 'Backend Service' in the given authorized app types.
	5. Give some description in the 'Description' text field.
	6. By default access token is valid for 2 hours. Adjust the timing based on your requirement.
	7. Click on the save button.
	8. Click on the 'Download Credentials' download button, enable 'Create Service Account', and then click on the 'DOWNLOAD'.
	
	Please place the downloaded file in './IMSSampleFlow/Data' folder with name 'BACKENDAPI.ionapi'
	
	
	
	
### Download service account

Follow these steps:
	1. Select User Management in User Menu.
	2. In the left panel, click on Manage, Service Accounts, and then click on plus button(Add new item).
	3. Give some description in the description text area, give the user email in 'User Email Address' box.
	4. Click on save, it downloads the service account in csv format.
	
	
	

### IMS via ION API connection point creation

Follow these steps:
	1. Open ION Desk.
	2. Open Connection Points page.
	3. Click on Add and then select 'IMS via ION API'.
	4. IMS endpoint and document configuration.
		In case of two way IMS:
			In IMS Endpoint section:
			1. Click on SELECT, select your IMS external application under products, and then select discovery API.
			2. Upload the downloaded service account by clicking on the IMPORT button.
			3. Go to the Documents tab, click on the refresh button. It gets the documents from the external application.
		In case of one way IMS:
			1. Un check the 'Application has IMS End Point' check box.
			2. Go to Documents tab, click on plus button, and then add the required documents in the list.
	5. Copy the 'ci' field value from the downloaded authorized app and paste it in the 'ION API Client Id' field.
	6. Finally, click on save.

	
	
	

### Before running the application, please make sure the following files available in the data folder.
	
	1. BACKENDAPI.ionapi                                  (To create this file, please follow the steps mentioned in the 'ION API Authorized app creation' section)
	
	2. MessageParameters.json                             (Replace the message parameters values with your data(EX: fromLogicalId))
	
	3. MessagePayload                                     (Replace MessagePayload file content with your message content. Please place the plain content only, internally we will do the deflate compression and sent that deflated content.)

	
	

### How to publish the message

	1. Build the project.
	2. Press the F5 key to publish the message.
	
