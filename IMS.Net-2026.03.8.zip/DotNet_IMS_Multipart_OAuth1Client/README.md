### NOTE
In this sample, we are blindly trusting the server certificate. That code is not production-ready.


### IMS connection point creation in OnPremise

Follow these steps:
	1. Open ION Desk.
	2. Open the Connection Points page.
	3. Click on Add and then select 'Infor Application(IMS)'.
	4. If you are creating an IMS application as a two way IMS. 
	   Then, select the 'Application has IMS End Point' check box and give the IMS Endpoint(external application) details.
	5. And then save the connection point and click on the 'GENERATE' button.
	   After clicking on the GENERATE button, it gives the ClientId and ClientSecret keys. These keys will be used to send the message from the IMS application.



### Before running the application, please make sure the following files available in the './Resources' folder.
	
	1. MessageParameters.json                             (Replace the message parameters values with your data(EX: fromLogicalId))
	2. MessagePayload                                     (Replace MessagePayload file content with your message content. Please place the plain content only, internally we will do the deflate compression and sent that deflated content.)
	3. Open the Program.cs in the IMS client project.
	   Replace the 'OAUTH_CONSUMER_KEY' & 'OAUTH_SECRET_KEY' variable values with the consumer and secret keys which are generated in the 5th step.
	   And replace the 'BASE_URL' variable value with the ION IMS application URL. And replace the 'TENANT_ID' variable value with the proper tenant Id used.
   


### How to publish the message

	1. Build the project.
	2. Press the F5 key to publish the message.
	
	
		
	
