﻿/**
 * ---Begin Copyright Notice--- Feb 4, 2021 11:52:46 AM
 *
 * Copyright 2021 Infor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * ---End Copyright Notice---
 */


using IMSSampleFlow.Helpers;
using System;

namespace IMSSampleFlow
{
    class Program
    {
        private static string BASE_URL = "dummyBaseURL";
        private static string OAUTH_CONSUMER_KEY = "dummyConsumerKey";
        private static string OAUTH_SECRET_KEY = "dummySecretKey";
        private static string TENANT_ID = "dummytenantId";
        static void Main(string[] args)
        {
            try
            {
                OAuthHelper oauthHelper = new OAuthHelper(BASE_URL, OAUTH_CONSUMER_KEY, OAUTH_SECRET_KEY);
                RestServiceHelper restServiceHelper = new RestServiceHelper(BASE_URL,TENANT_ID);

                Console.WriteLine("Starting the message sending process:");

                Console.WriteLine("1. Calling the ping service...");
                restServiceHelper.ping(oauthHelper);

                Console.WriteLine("\n2. Calling the version service...");
                restServiceHelper.getSupportedVersions(oauthHelper);

                Console.WriteLine("\n3. Calling the acceptedDocuments service...");
                restServiceHelper.acceptedDocuments(oauthHelper);

                Console.WriteLine("\n4. Calling the multipartMessage service...");
                restServiceHelper.sendMultipartMessage(oauthHelper);

                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
                Console.WriteLine("This might be the issue with key and secret or base URL, if all the three are correct please contact the developer");
                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
                System.Environment.Exit(0);
            }
        }
    }
}

