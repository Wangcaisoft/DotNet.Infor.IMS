﻿/**
 * ---Begin Copyright Notice--- Feb 4, 2021 11:52:46 AM
 *
 * Copyright 2021 Infor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * ---End Copyright Notice---
 */


using OAuth;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace IMSSampleFlow.Helpers
{
    class OAuthHelper
    {
        private string BASE_URL;

        private string OAUTH_CONSUMER_KEY;

        private string OAUTH_SECRET_KEY;

        public OAuthHelper(string url, string consumerKey, string secretKey)
        {
            BASE_URL = url;
            OAUTH_CONSUMER_KEY = consumerKey;
            OAUTH_SECRET_KEY = secretKey;
        }

        public string generateOAuth1Token(string path, string method)
        {
            string tokenSecret = string.Empty;
            var consumerSecret = string.Format("{0}&{1}", OAUTH_SECRET_KEY, tokenSecret);
            string uri = BASE_URL + path;

            string signatureMethod = "HMAC-SHA256";
            string timeStamp = OAuthTools.GetTimestamp(DateTime.UtcNow);
            string nonce = OAuthTools.GetNonce();
            string oauthVersion = "1.0";
            string SimpleQuote(string s) => '"' + s + '"';

            string oauthHeader = "oauth_consumer_key=" + SimpleQuote(OAUTH_CONSUMER_KEY) + ",oauth_signature_method=" + SimpleQuote(signatureMethod) + ",oauth_timestamp=" + SimpleQuote(timeStamp) + ",oauth_nonce=" + SimpleQuote(nonce) + ",oauth_version=" + SimpleQuote(oauthVersion);

            WebParameterCollection parameterCollection = new WebParameterCollection()
            {
                new WebParameter("oauth_consumer_key", OAUTH_CONSUMER_KEY),
                new WebParameter("oauth_nonce", nonce),
                new WebParameter("oauth_signature_method", signatureMethod),
                new WebParameter("oauth_timestamp", timeStamp),
                new WebParameter("oauth_version", "1.0"),
            };
            string signature = OAuthTools.ConcatenateRequestElements(method.ToUpperInvariant(), uri, parameterCollection);
            var signmethod = GetSignatureMethod(signatureMethod);
            var encodedSignature = EncodeSignature(consumerSecret, signature);
            encodedSignature = HttpUtility.UrlEncode(encodedSignature);
            var header =
                "OAuth oauth_consumer_key=" + SimpleQuote(OAUTH_CONSUMER_KEY) + "," +
                "oauth_nonce=" + SimpleQuote(nonce) + "," +
                "oauth_signature_method=" + SimpleQuote("HMAC-SHA256") + "," +
                "oauth_timestamp=" + SimpleQuote(timeStamp) + "," +
                "oauth_signature= " + SimpleQuote(encodedSignature) + "," +
                "oauth_version=" + SimpleQuote("1.0");

            return header;
        }

        public OAuthRequest CreateFromAuthorizationHeader(string method, string requestUri, string query, string authorizationHeader)
        {
            var parameters = CreateDictionaryFromAuthorizationHeader(authorizationHeader)
                .Where(ParameterHasAValue)
                .Select(UnescapedValues)
                .ToDictionary(k => k.Key, k => k.Value);

            AddQueryStringParameters(query, ref parameters);

            return new OAuthRequest
            {
                ConsumerKey = GetHeaderValue(parameters, "oauth_consumer_key"),
                SignatureMethod = GetHeaderValue(parameters, "oauth_signature_method"),
                Signature = GetHeaderValue(parameters, "oauth_signature"),
                Timestamp = GetHeaderValue(parameters, "oauth_timestamp"),
                Nonce = GetHeaderValue(parameters, "oauth_nonce"),
                Version = GetHeaderValue(parameters, "oauth_version"),
                ValueToSign = BuildBaseSigningValue(method, requestUri, parameters)
            };
        }

        private static void AddQueryStringParameters(string query, ref Dictionary<string, string> parameters)
        {
            if (!string.IsNullOrWhiteSpace(query))
            {
                NameValueCollection nvcData = HttpUtility.ParseQueryString(query);
                foreach (string key in nvcData.AllKeys)
                {
                    if (!string.IsNullOrWhiteSpace(key) && !parameters.ContainsKey(key))
                    {
                        string encodedKey = UrlEncodeWithCaptialEscapeCharacters(key);
                        string encodedValue = UrlEncodeWithCaptialEscapeCharacters(nvcData.Get(key)); ;
                        parameters.Add(encodedKey, encodedValue);
                    }
                }
                //If the query string has only key values. Ex: ?UserIDs&languageId=en-US

                string[] emptyKeyValues = nvcData.GetValues(null);

                if (emptyKeyValues != null)
                {
                    foreach (string key in emptyKeyValues)
                    {
                        if (!string.IsNullOrWhiteSpace(key) && !parameters.ContainsKey(key))
                        {
                            string encodedKey = UrlEncodeWithCaptialEscapeCharacters(key); ;
                            parameters.Add(key, "");
                        }
                    }
                }
            }
        }
        private static KeyValuePair<string, string> UnescapedValues(KeyValuePair<string, string> kvp)
        {
            return new KeyValuePair<string, string>(kvp.Key, Uri.UnescapeDataString(kvp.Value));
        }
        private static IEnumerable<KeyValuePair<string, string>> CreateDictionaryFromAuthorizationHeader(string oauth)
        {
            return oauth.Split(',')
                    .Select(x => x.Split('='))
                    .Where(x => x.Length == 2)
                    .ToDictionary(k => k[0].Trim(), v => v[1].Trim().Trim('"'));
        }
        
        private static bool ParameterHasAValue(KeyValuePair<string, string> kvp)
        {
            return !string.IsNullOrWhiteSpace(kvp.Value);
        }

        private static string GetHeaderValue(IDictionary<string, string> args, string name)
        {
            return args.ContainsKey(name) ? args[name] : null;
        }
        private static string BuildBaseSigningValue(string method, string requestUri, IEnumerable<KeyValuePair<string, string>> parameters)
        {
            return string.Format(@"{0}&{1}&{2}",
                method,
                UrlEncodeWithCaptialEscapeCharacters(requestUri),
                UrlEncodeWithCaptialEscapeCharacters(BuildParametersForSignature(parameters))
                );
        }
        private static string UrlEncodeWithCaptialEscapeCharacters(string valueToEncode)
        {
            var encodedWithLowerCase = HttpUtility.UrlEncode(valueToEncode);
            Regex reg = new Regex(@"%[a-f0-9]{2}");
            return reg.Replace(encodedWithLowerCase, m => m.Value.ToUpperInvariant());
        }
        private static string BuildParametersForSignature(IEnumerable<KeyValuePair<string, string>> parameters)
        {
            return String.Join("&",
                FindAndSortParametersForSignature(parameters)
                    .Select(FormatParameterForSignature));
        }

        private static IEnumerable<KeyValuePair<string, string>> FindAndSortParametersForSignature(IEnumerable<KeyValuePair<string, string>> parameters)
        {
            return parameters
                .Where(x => (x.Key != "oauth_signature" && x.Key != "realm"))
                .OrderBy(x => x.Key, new CustomComparer());
        }

        private static string FormatParameterForSignature(KeyValuePair<string, string> parameter)
        {
            return string.Format("{0}={1}", parameter.Key, parameter.Value);
        }

        private static string EncodeHmacsha256(string consumerSecret, string baseSigningValue)
        {
            var key = Encoding.UTF8.GetBytes(consumerSecret);
            var encrypter = new HMACSHA256(key);
            var bytes = encrypter.ComputeHash(Encoding.UTF8.GetBytes(baseSigningValue));
            return Convert.ToBase64String(bytes);
        }

        private static SignatureMethod GetSignatureMethod(string signatureMethod)
        {
            switch (signatureMethod.ToUpper())
            {
                case "HMAC-SHA1":
                    return SignatureMethod.Hmacsha1;

                case "HMAC-SHA256":
                    return SignatureMethod.Hmacsha256;

                case "RSA-SHA1":
                    return SignatureMethod.Rsasha1;

                case "PLAINTEXT":
                    return SignatureMethod.Plaintext;

                default:
                    return SignatureMethod.Unknown;
            }
        }
        private static string EncodeSignature(string consumerSecret, string baseSigningValue)
        {
            return EncodeHmacsha256(consumerSecret, baseSigningValue);
        }
    }

    public class CustomComparer : IComparer<string>
    {
        public int Compare(string x, string y)
        {
            return string.Compare(x, y, StringComparison.Ordinal);
        }
    }

    public class OAuthRequest
    {
        public string ConsumerKey { get; set; }

        public string Token { get; set; }

        public string SignatureMethod { get; set; }

        public string Signature { get; set; }

        public string Timestamp { get; set; }

        public string Nonce { get; set; }

        public string Version { get; set; }

        public string ValueToSign { get; set; }
    }

    public enum SignatureMethod
    {
        Unknown,
        Hmacsha1,
        Hmacsha256,
        Rsasha1,
        Plaintext,
    }
}
