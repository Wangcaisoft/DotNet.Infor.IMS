﻿/**
 * ---Begin Copyright Notice--- Feb 4, 2021 11:52:46 AM
 *
 * Copyright 2021 Infor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * ---End Copyright Notice---
 */


using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Text;

namespace IMSSampleFlow.Helpers
{
    class RestServiceHelper
    {
        private static string BASE_URL;

        private static string TENANT_ID;

        public RestServiceHelper(string url, string tenantId)
        {
            BASE_URL = url;
            TENANT_ID = tenantId;
        }

        public void sendMultipartMessage(OAuthHelper oauthHelper)
        {
            System.IO.Compression.DeflateStream deflate = null;
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                Console.WriteLine("WARNING:We are blindly trusting the server certificate as this code is not production ready");

                using (var client = new System.Net.Http.HttpClient(clientHandler))
                {
                    string contentID = Guid.NewGuid().ToString();
                    using (MemoryStream ms = new MemoryStream())
                    {
                        string assemblyLocation = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;

                        // Loading ParameterRequest file.
                        string parameterFile = System.IO.File.ReadAllText(assemblyLocation + "\\Resources\\MessageParameters.json");
                        // 1. Creating one of the multipart request parameter 'ParameterRequest'.
                        System.Net.Http.HttpContent paramContent = new System.Net.Http.StringContent(parameterFile);
                        // Setting request headers to 'ParameterRequest' multipart body part.
                        paramContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
                        paramContent.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("form-data") { Name = "ParameterRequest" };

                        // 2. Creating another multipart request parameter 'MessagePayload'.
                        string bodyFile = System.IO.File.ReadAllText(assemblyLocation + "\\Resources\\MessagePayload");
                        byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(bodyFile);
                        byte[] compatibleHeader = { 0x78, 0x01 };
                        ms.Write(compatibleHeader, 0, compatibleHeader.Length);

                        // Doing the deflate compression to message body.
                        using (deflate = new DeflateStream(ms, CompressionLevel.Fastest, true))
                        {
                            deflate.Write(byteArray, 0, byteArray.Length);
                            deflate.Flush();
                        }

                        ms.Write(Adler32(byteArray, 0, byteArray.Length), 0, 4);
                        ms.Flush();
                        ms.Position = 0;

                        System.Net.Http.HttpContent bodyContent = new System.Net.Http.StreamContent(ms);
                        // Setting request headers to 'MessagePayload' multipart body part.
                        bodyContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                        bodyContent.Headers.Add("Content-Transfer-Encoding", "binary");
                        bodyContent.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("form-data") { Name = "MessagePayload" };

                        // 3. Create multipart request and adding two parameters(ParameterRequest and MessagePayload) which are created in the above steps.
                        System.Net.Http.MultipartContent content = new System.Net.Http.MultipartContent("form-data", contentID);
                        content.Add(paramContent);
                        content.Add(bodyContent);

                        // 4. Adding tenantId header to the multipart request.
                        client.DefaultRequestHeaders.Add("X-TenantId", TENANT_ID);

                        var url = BASE_URL + "/v3/multipartMessage";
                        // 5. Generating the oauth token.
                        string authorization = oauthHelper.generateOAuth1Token("/v3/multipartMessage", "POST");
                        client.DefaultRequestHeaders.Add("Authorization", authorization);

                        // 6. Calling the multipartMessage service.
                        var result = client.PostAsync(url, content).Result;

                        // 7. Validating the result.
                        int statusCode = (int)result.StatusCode;
                        var responseBody = result.Content.ReadAsStringAsync().Result;
                        if (statusCode == 202)
                        {
                            Console.WriteLine("Multipart message delivered successfully with response: " + responseBody);
                        }
                        else if (statusCode == 401 || statusCode == 403 || statusCode == 404 || statusCode == 406 || statusCode == 408 || statusCode == 415 || statusCode == 500 || statusCode == 502 || statusCode == 503 || statusCode == 504)
                        {
                            Console.WriteLine("Something problem in request information or at server side. Stopping the message sending process(retry logic here in case of original message sending process).");
                            Console.WriteLine("Received response body: " + responseBody);
                            Console.WriteLine("Press any key to exit...");
                            Console.ReadKey();
                            System.Environment.Exit(0);
                        }
                        else
                        {
                            Console.WriteLine("Send multipart message failed with response: " + responseBody);
                            Console.WriteLine("Press any key to exit...");
                            Console.ReadKey();
                            System.Environment.Exit(0);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void ping(OAuthHelper oauthHelper)
        {
            HttpClientHandler clientHandler = new HttpClientHandler();
            clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
            Console.WriteLine("WARNING:We are blindly trusting the server certificate as this code is not production ready");
            using (var client = new System.Net.Http.HttpClient(clientHandler))
            {
                string authorization = oauthHelper.generateOAuth1Token("/ping", "GET");
                client.DefaultRequestHeaders.Add("Authorization", authorization);
                var pingUrl = BASE_URL + "/ping";
                var pingResult = client.GetAsync(pingUrl).Result;

                Stream streamResbody = pingResult.Content.ReadAsStreamAsync().Result;
                StreamReader readStream = new StreamReader(streamResbody, Encoding.UTF8);
                string responseBody = readStream.ReadToEnd();

                int statusCode = (int)pingResult.StatusCode;
                if (statusCode == 200)
                {
                    Console.WriteLine("Ping succeeded with response: " + responseBody);
                }
                else if (statusCode == 401 || statusCode == 403 || statusCode == 404 || statusCode == 406 || statusCode == 408 || statusCode == 415 || statusCode == 500 || statusCode == 502 || statusCode == 503 || statusCode == 504)
                {
                    Console.WriteLine("Something problem in request information or at server side. Stopping the message sending process(retry logic here in case of original message sending process).");
                    Console.WriteLine("Received response body: " + responseBody);
                    Console.WriteLine("Press any key to exit...");
                    Console.ReadKey();
                    System.Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Ping failed. Stopping the message sending process.");
                    Console.WriteLine("Received response body: " + responseBody);
                    Console.WriteLine("Press any key to exit...");
                    Console.ReadKey();
                    System.Environment.Exit(0);
                }
            }
        }

        public void acceptedDocuments(OAuthHelper oauthHelper)
        {
            HttpClientHandler clientHandler = new HttpClientHandler();
            clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
            Console.WriteLine("WARNING:We are blindly trusting the server certificate as this code is not production ready");
            using (var client = new System.Net.Http.HttpClient(clientHandler))
            {
                string assemblyLocation = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;
                // Getting the documentName and fromLogicalId from message parameter file for the validation.
                string parameterRequestFile = System.IO.File.ReadAllText(assemblyLocation + "\\Resources\\MessageParameters.json");
                Newtonsoft.Json.Linq.JObject parameterRequest = Newtonsoft.Json.Linq.JObject.Parse(parameterRequestFile);
                string documentName = (string)parameterRequest.SelectToken("documentName");
                string fromLogicalId = (string)parameterRequest.SelectToken("fromLogicalId");

                if (null == fromLogicalId)
                {
                    throw new Exception("Please provide the fromLogicalId in ParameterRequest file.");
                }
                if (null == documentName)
                {
                    throw new Exception("Please provide the documentName in ParameterRequest file.");
                }

                string encodedLogicalId = System.Web.HttpUtility.UrlEncode(fromLogicalId);


                var acceptedDocUrl = BASE_URL + "/v3/" + encodedLogicalId + "/acceptedDocuments";
                client.DefaultRequestHeaders.Add("X-TenantId", TENANT_ID);
                string authorization = oauthHelper.generateOAuth1Token("/v3/" + encodedLogicalId + "/acceptedDocuments", "GET");
                client.DefaultRequestHeaders.Add("Authorization", authorization);

                var acceptedDocResult = client.GetAsync(acceptedDocUrl).Result;

                Stream streamResbody = acceptedDocResult.Content.ReadAsStreamAsync().Result;
                StreamReader readStream = new StreamReader(streamResbody, Encoding.UTF8);
                string responseBody = readStream.ReadToEnd();

                int statusCode = (int)acceptedDocResult.StatusCode;
                if (statusCode == 200)
                {
                    Newtonsoft.Json.Linq.JObject jsonResponse = Newtonsoft.Json.Linq.JObject.Parse(responseBody);
                    List<string> acceptedDocuments = jsonResponse.SelectToken("acceptedDocuments").ToObject<List<string>>();
                    string logicalId = (string)jsonResponse.SelectToken("logicalId");

                    Console.WriteLine("acceptedDocuments call succeeded with response: " + responseBody);
                    if (!acceptedDocuments.Contains(documentName) || !logicalId.Equals(fromLogicalId))
                    {
                        Console.WriteLine("The document '" + documentName + "' is not configured for the sending application '" + logicalId + "'. Please configure and try again later.");
                        Console.WriteLine("\nStopping the message sending process.");
                        Console.WriteLine("Press any key to exit...");
                        Console.ReadKey();
                        System.Environment.Exit(0);
                    }
                    else
                    {
                        Console.WriteLine("The document '" + documentName + "' is configured for the sending application '" + logicalId + "'.");
                    }
                }
                else
                {
                    Console.WriteLine("acceptedDocuments call failed with response: " + responseBody);
                    Console.WriteLine("Press any key to exit...");
                    Console.ReadKey();
                    System.Environment.Exit(0);
                }
            }
        }

        public void getSupportedVersions(OAuthHelper oauthHelper)
        {
            try
            {
                HttpClientHandler clientHandler = new HttpClientHandler();
                clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
                Console.WriteLine("WARNING:We are blindly trusting the server certificate as this code is not production ready");
                List<string> supportedVersions = null;
                using (var client = new System.Net.Http.HttpClient(clientHandler))
                {
                    var versionsUrl = BASE_URL + "/versions";
                    string authorization = oauthHelper.generateOAuth1Token("/versions", "GET");
                    client.DefaultRequestHeaders.Add("Authorization", authorization);
                    HttpResponseMessage versionsResult = client.GetAsync(versionsUrl).Result;

                    int statusCode = (int)versionsResult.StatusCode;
                    Stream streamResbody = versionsResult.Content.ReadAsStreamAsync().Result;
                    StreamReader readStream = new StreamReader(streamResbody, Encoding.UTF8);
                    string responseBody = readStream.ReadToEnd();

                    if (statusCode == 200)
                    {
                        Console.WriteLine("Versions call succeeded with response: " + responseBody);

                        Newtonsoft.Json.Linq.JObject jsonResponse = Newtonsoft.Json.Linq.JObject.Parse(responseBody);
                        var versions = jsonResponse.SelectToken("supportedVersions");
                        if (null != versions)
                        {
                            supportedVersions = versions.ToObject<List<string>>();
                        }
                        if (null == versions || !supportedVersions.Contains("v3"))
                        {
                            Console.WriteLine("Minimum version required to run this project is v3..");
                            Console.WriteLine("\nStopping the message sending process.");
                            Console.WriteLine("Press any key to exit...");
                            Console.ReadKey();
                            System.Environment.Exit(0);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Versions call failed with response: " + responseBody);
                        Console.WriteLine("\nStopping the message sending process.");
                        Console.WriteLine("Press any key to exit...");
                        Console.ReadKey();
                        System.Environment.Exit(0);
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        /// <summary>
        ///   Calculate the Adler32 checksum for zlib use.
        /// </summary>
        /// <param name="data"></param>
        /// <param name="offset"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static byte[] Adler32(byte[] data, int offset, int length)
        {
            uint Modulus = 65521;
            uint a = 1;
            uint b = 0;
            byte[] adlerBytes;
            for (int counter = 0; counter < length; ++counter)
            {
                a = (a + (data[offset + counter])) % Modulus;
                b = (b + a) % Modulus;
            }
            adlerBytes = BitConverter.GetBytes(unchecked((uint)((b << 16) + a)));
            Array.Reverse(adlerBytes);
            return adlerBytes;
        }
    }
}
