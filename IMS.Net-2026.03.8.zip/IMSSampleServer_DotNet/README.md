### Open the visual studio in Admin(super user) mode before opening the project in it.

### Before building the application, please make sure to download the following packages.
	
	Open the visual studio, go to tools --> NuGet Package Manager --> Manage Nuget Packages for Solutions
	And then click on 'Browse' tab. And search for the following dependencies in the search box and then download those.
	
	1. Microsoft.AspNet.WebApi.Core
	   If the latest version not working, then please download the "5.2.7" version.
	   
	2. Microsoft.AspNet.WebApi.Client
	   If the latest version not working, then please download the "5.2.7" version.
	   
	3. Microsoft.AspNet.WebApi.SelfHost
	   If the latest version not working, then please download the "5.2.7" version.
	   
	4. Microsoft.AspNet.WebApi.WebHost
	   If the latest version not working, then please download the "5.2.4" version.
	   
	5. MultipartDataMediaFormatter.V2
	   If the latest version not working, then please download the "2.0.3" version.
	   
	6. Newtonsoft.Json
	   If the latest version not working, then please download the "11.0.1" version.
	   
    7. Microsoft.CodeDom.Providers.DotNetCompilerPlatform
       If the latest version not working, then please download the "2.0.0" version.

	   


### How to start the server with http port
	1. Make sure the port number 8081 is available. If not, please change the port number in 'WebApiConfig.cs' file.
	2. Build the project.
	3. Press the F5 key to start the server.

	baseURL: http://<<HOSTNAME>>.infor.com:8081

### NOTE	
	Recommended passing the MessagePayload and MessageParameter files as multipart file body parts rather than text body parts. Because some validations for text body parts are missing in this sample. 

### How to start the server with https port
	1. Make sure the port number 8081 is available. If not, please change the port number in 'WebApiConfig.cs' file.
	2. Create the SSL certificate in IIS
	   Run the following command in administrator mode. Here replace the following certhash with your certificate hash.
	   "netsh http add sslcert ipport=0.0.0.0:8081 certhash=3daff9a23e2645a4756ec671d99ad3f9f04348c0 appid={2d6059b2-cccb-4a83-ae08-8ce209c2c5c1}"
	3. Replace HttpSelfHostConfiguration with MyHttpsSelfHostConfiguration in 'WebApiConfig.cs' file.
	4. Build the project.
	5. Press the F5 key to start the server.
	
	baseURL: https://<<HOSTNAME>>.infor.com:8081
	
### Available APIs
	1. ping
	2. protocol
	3. multipartMessage


### URL info
	ping URL              : baseURL/ping
	protocol URL          : baseURL/protocol
	multipartMessage URL  : baseURL/v3/multipartMessage
	