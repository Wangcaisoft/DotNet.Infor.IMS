﻿/**
 * ---Begin Copyright Notice--- Feb 4, 2021 11:52:46 AM
 *
 * Copyright 2021 Infor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * ---End Copyright Notice---
 */

using MultipartDataMediaFormatter;
using MultipartDataMediaFormatter.Infrastructure;
using System;
using System.Web.Http;
using System.Web.Http.SelfHost;

namespace IMSSampleApplication
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            HttpSelfHostConfiguration selfHostConfig = new HttpSelfHostConfiguration("http://localhost:8081");

            selfHostConfig.MapHttpAttributeRoutes();

            selfHostConfig.Formatters.Add(new FormMultipartEncodedMediaTypeFormatter(new MultipartFormatterSettings()));

            using (HttpSelfHostServer server = new HttpSelfHostServer(selfHostConfig))
            {
                server.OpenAsync().Wait();
                Console.WriteLine("Press Enter to quit.");
                Console.ReadLine();
            }
        }
    }
}
