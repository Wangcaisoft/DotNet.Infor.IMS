﻿/**
 * ---Begin Copyright Notice--- Feb 4, 2021 11:52:46 AM
 *
 * Copyright 2021 Infor
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * ---End Copyright Notice---
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IMSSampleApplication.Models
{
    public class MultipartMessageResponse
    {
        public MultipartMessageResponse(string status, int code, string message)
        {
            this.code = code;
            this.status = status;
            this.message = message;
        }

        public int code { get; set; }
        public string status { get; set; }

        public string message { get; set; }
    }
}